import cv2
import numpy as np

image_path = "hola_1.png"   # Carga de grafica que queremos digitalizar

CLICK_TOLERANCIA = 3
NUM_PUNTOS_CURVA = 200

# Variables globales
fase_actual = 0                   
puntos_cal_x = []
puntos_cal_y = []
pendiente_x = interseccion_x = None
pendiente_y = interseccion_y = None
imagen_original = None
imagen_interactiva = None


# Funcion para la deteccion de la curva 
def extraer_curva_por_geometria(imagen_bgr, cantidad_puntos=200):
    
    imagen_gris = cv2.cvtColor(imagen_bgr, cv2.COLOR_BGR2GRAY)
    imagen_suavizada = cv2.GaussianBlur(imagen_gris, (5, 5), 0)

    # 1. Bordes
    bordes = cv2.Canny(imagen_suavizada, 50, 150)

    # 2. Detectar líneas rectas (ejes + grid) y borrarlas del mapa de bordes
    altura, ancho = bordes.shape
    lineas = cv2.HoughLinesP(
        bordes,
        rho=1,
        theta=np.pi / 180,
        threshold=80,
        minLineLength=min(altura, ancho) // 4,
        maxLineGap=10
    )

    mascara_sin_lineas = bordes.copy()

    if lineas is not None:
        for x1, y1, x2, y2 in lineas[:, 0]:
            # Consideramos líneas casi horizontales o casi verticales
            if abs(y1 - y2) <= 2 or abs(x1 - x2) <= 2:
                # "borramos" esa línea de la imagen de bordes
                cv2.line(mascara_sin_lineas, (x1, y1), (x2, y2), 0, 3)

    # Opcional: un pequeño cierre para unir la curva si quedó cortada
    kernel = np.ones((3, 3), np.uint8)
    mascara_sin_lineas = cv2.morphologyEx(mascara_sin_lineas, cv2.MORPH_CLOSE, kernel, iterations=1)

    # 3. Buscar contornos en la máscara filtrada
    contornos, _ = cv2.findContours(mascara_sin_lineas, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contornos:
        return []

    # Nos quedamos con el contorno más largo (asumimos que es la curva principal)
    contorno_principal = max(contornos, key=lambda c: len(c))
    puntos = contorno_principal.reshape(-1, 2)

    # Ordenamos por X (izquierda a derecha) para tener un "recorrido" coherente
    puntos = puntos[np.argsort(puntos[:, 0])]

    total = len(puntos)
    if total == 0:
        return []

    # 4. Muestreo uniforme a lo largo de la curva
    if total > cantidad_puntos:
        indices = np.linspace(0, total - 1, cantidad_puntos).astype(int)
        puntos_muestreados = puntos[indices]
    else:
        puntos_muestreados = puntos

    return puntos_muestreados.tolist()


# Calibracion del mouse
def manejar_click(evento, x, y, flags, param):
    global fase_actual, puntos_cal_x, puntos_cal_y
    global pendiente_x, interseccion_x, pendiente_y, interseccion_y
    global imagen_original, imagen_interactiva

    # Calibracion del eje x 
    if evento == cv2.EVENT_LBUTTONDOWN and fase_actual == 0:
        puntos_cal_x.append((x, y))
        cv2.circle(imagen_interactiva, (x, y), 4, (0, 0, 255), -1)
        cv2.putText(imagen_interactiva, f"X{len(puntos_cal_x)}", (x + 5, y - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
        print(f"Clic eje X {len(puntos_cal_x)} en píxeles: ({x}, {y})")

        if len(puntos_cal_x) == 2:
            (x1, y1), (x2, y2) = puntos_cal_x

            # Validar alineación horizontal
            if abs(y1 - y2) > CLICK_TOLERANCIA:
                print("\n[ERROR] Los puntos del eje X no están alineados horizontalmente.")
                puntos_cal_x.clear()
                imagen_interactiva[:] = imagen_original
                return

            x_real_1 = float(input("Valor real del primer punto del eje X: "))
            x_real_2 = float(input("Valor real del segundo punto del eje X: "))

            if x1 == x2:
                print("Error: los puntos X tienen la misma coordenada de píxel. Repite.")
                puntos_cal_x.clear()
                imagen_interactiva[:] = imagen_original
                return

            pendiente_x = (x_real_2 - x_real_1) / (x2 - x1)
            interseccion_x = x_real_1 - pendiente_x * x1

            print(f"Calibración X OK: x_real = {pendiente_x:.6f} * pix_x + {interseccion_x:.6f}")
            fase_actual = 1
            print("\nAhora selecciona 2 puntos sobre el eje Y.")

    # Calibracion del eje Y
    elif evento == cv2.EVENT_LBUTTONDOWN and fase_actual == 1:
        puntos_cal_y.append((x, y))
        cv2.circle(imagen_interactiva, (x, y), 4, (0, 255, 0), -1)
        cv2.putText(imagen_interactiva, f"Y{len(puntos_cal_y)}", (x + 5, y - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        print(f"Clic eje Y {len(puntos_cal_y)} en píxeles: ({x}, {y})")

        if len(puntos_cal_y) == 2:
            (x1, y1), (x2, y2) = puntos_cal_y

            # Validar alineación vertical
            if abs(x1 - x2) > CLICK_TOLERANCIA:
                print("\n[ERROR] Los puntos del eje Y no están alineados verticalmente.")
                puntos_cal_y.clear()
                imagen_interactiva[:] = imagen_original

                # Redibujar puntos del eje X
                for i, (px, py) in enumerate(puntos_cal_x, start=1):
                    cv2.circle(imagen_interactiva, (px, py), 4, (0, 0, 255), -1)
                    cv2.putText(imagen_interactiva, f"X{i}", (px + 5, py - 5),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
                return

            y_real_1 = float(input("Valor real del primer punto del eje Y: "))
            y_real_2 = float(input("Valor real del segundo punto del eje Y: "))

            if y1 == y2:
                print("Error: los puntos Y tienen la misma coordenada de píxel. Repite.")
                puntos_cal_y.clear()
                imagen_interactiva[:] = imagen_original
                return

            pendiente_y = (y_real_2 - y_real_1) / (y2 - y1)
            interseccion_y = y_real_1 - pendiente_y * y1

            print(f"Calibración Y OK: y_real = {pendiente_y:.6f} * pix_y + {interseccion_y:.6f}")
            fase_actual = 2
            print("\nCalibración completa. Pulsa ESC para digitalizar la curva.")


# Funcion Principal
def main():
    global imagen_original, imagen_interactiva, fase_actual
    global pendiente_x, pendiente_y, interseccion_x, interseccion_y

    imagen_original_local = cv2.imread(image_path)
    if imagen_original_local is None:
        print(f"No se pudo cargar la imagen '{image_path}'.")
        return

    # Guardamos en global
    imagen_original = imagen_original_local
    imagen_interactiva = imagen_original.copy()

    cv2.namedWindow("Digitalizador")
    cv2.setMouseCallback("Digitalizador", manejar_click)

    print("Fase 0: selecciona 2 puntos del eje X.")

    # Bucle de interacción hasta calibrar o salir
    while True:
        cv2.imshow("Digitalizador", imagen_interactiva)
        tecla = cv2.waitKey(20) & 0xFF
        if tecla == 27:         # ESC
            break
        if fase_actual == 2:    # Calibración terminada
            break

    cv2.destroyAllWindows()

    # Verificamos calibración
    if pendiente_x is None or pendiente_y is None:
        print("No se completó la calibración. Saliendo.")
        return

    # --- Detección de curva por geometría ---
    puntos_pixeles = extraer_curva_por_geometria(imagen_original, NUM_PUNTOS_CURVA)
    if not puntos_pixeles:
        print("No se pudo detectar una curva principal.")
        return

    #Conversión de pixeles a coordenadas reales
    puntos_reales = []
    for px, py in puntos_pixeles:
        x_real = pendiente_x * px + interseccion_x
        y_real = pendiente_y * py + interseccion_y
        puntos_reales.append((x_real, y_real))

    puntos_reales = np.array(puntos_reales)

    print("\nPUNTOS DIGITALIZADOS (x_real, y_real):")
    for i, (xr, yr) in enumerate(puntos_reales, start=1):
        print(f"Punto {i:03d}: x = {xr:.4f}, y = {yr:.4f}")

    np.savetxt("puntos_digitalizados_geom.txt", puntos_reales, header="x y", comments="")
    print("\nPuntos guardados en 'puntos_digitalizados_geom.txt'.")


if __name__ == "__main__":
    main()
